package com.example.demo.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoPlans1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
