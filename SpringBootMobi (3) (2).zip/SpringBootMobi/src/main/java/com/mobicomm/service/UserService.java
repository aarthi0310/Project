package com.mobicomm.service;

import com.mobicomm.dto.PaymentConfirmationRequest;
import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.entity.User;
import com.mobicomm.repository.RechargeHistoryRepository;
import com.mobicomm.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RechargeHistoryRepository rechargeHistoryRepository;

    @Autowired
    private EmailService emailService;

    public boolean isRegisteredUser(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber).isPresent();
    }

    public boolean transactionExists(String transactionId) {
        return rechargeHistoryRepository.findByTransactionId(transactionId).isPresent();
    }

    @Transactional
    public void saveRechargeHistory(PaymentConfirmationRequest request) {
        String phoneNumber = sanitizePhoneNumber(request.getPhoneNumber());
        logger.info("Saving recharge history for phone number: {}", phoneNumber);

        Optional<User> userOptional = userRepository.findByPhoneNumber(phoneNumber);
        if (!userOptional.isPresent()) {
            logger.error("User not found with phone number: {}", phoneNumber);
            throw new RuntimeException("User not found with phone number: " + phoneNumber);
        }
        User user = userOptional.get();

        if (transactionExists(request.getTransactionId())) {
            logger.warn("Transaction {} already processed", request.getTransactionId());
            throw new RuntimeException("Transaction " + request.getTransactionId() + " already processed");
        }

        int days = parseValidityDays(request.getValidity());
        LocalDateTime expiryDate = LocalDateTime.now().plusDays(days);

        RechargeHistory recharge = new RechargeHistory();
        recharge.setUser(user);
        recharge.setName(user.getName());
        recharge.setPhoneNumber(phoneNumber);
        recharge.setPlanName(request.getPlanName());
        recharge.setAmount(request.getAmount());
        recharge.setPaymentMethod(request.getPaymentMethod());
        recharge.setTransactionId(request.getTransactionId());
        recharge.setRechargeDate(LocalDateTime.now());
        recharge.setExpiryDate(expiryDate);
        recharge.setEmail(user.getEmail());
        recharge.setNotified(false);

        logger.info("Saving recharge history: {}", recharge);
        RechargeHistory savedRecharge = rechargeHistoryRepository.save(recharge);
        logger.info("Recharge history saved with ID: {}", savedRecharge.getId());

        sendConfirmationEmail(savedRecharge);
    }

    private String sanitizePhoneNumber(String phoneNumber) {
        if (phoneNumber.startsWith("+91")) {
            return phoneNumber.substring(3);
        }
        return phoneNumber;
    }

    private int parseValidityDays(String validity) {
        try {
            return Integer.parseInt(validity.split(" ")[0]);
        } catch (Exception e) {
            logger.error("Invalid validity format: {}", validity, e);
            throw new IllegalArgumentException("Invalid validity format: " + validity);
        }
    }

    private void sendConfirmationEmail(RechargeHistory recharge) {
        if (recharge.getEmail() != null && !recharge.getEmail().isEmpty()) {
            try {
                emailService.sendRechargeConfirmationEmail(recharge.getEmail(), recharge);
                logger.info("Sent recharge confirmation email to: {}", recharge.getEmail());
            } catch (Exception e) {
                logger.error("Failed to send email to {}: {}", recharge.getEmail(), e.getMessage());
            }
        } else {
            logger.warn("No email found for user, skipping email notification");
        }
    }

    public List<RechargeHistory> getRechargeHistoryByPhoneNumber(String phoneNumber) {
        return rechargeHistoryRepository.findByPhoneNumber(sanitizePhoneNumber(phoneNumber));
    }

    public List<RechargeHistory> getAllRechargeHistory() {
        return rechargeHistoryRepository.findAll();
    }

    public List<Map<String, Object>> getGroupedRechargeHistory() {
        return rechargeHistoryRepository.findAll().stream()
            .collect(Collectors.groupingBy(RechargeHistory::getPhoneNumber))
            .entrySet().stream()
            .map(entry -> {
                List<RechargeHistory> recharges = entry.getValue();
                RechargeHistory latestRecharge = recharges.stream()
                        .max((r1, r2) -> r1.getRechargeDate().compareTo(r2.getRechargeDate()))
                        .orElse(null);

                if (latestRecharge != null) {
                    return Map.of(
                        "id", latestRecharge.getId(),
                        "name", latestRecharge.getName(),
                        "phoneNumber", latestRecharge.getPhoneNumber(),
                        "planName", latestRecharge.getPlanName(),
                        "expiryDate", latestRecharge.getExpiryDate().toString(),
                        "notified", latestRecharge.isNotified(),
                        "transactions", recharges.stream().map(r -> Map.of(
                            "date", r.getRechargeDate().toString(),
                            "plan", r.getPlanName(),
                            "amount", r.getAmount(),
                            "paymentMode", r.getPaymentMethod(),
                            "status", "Successful"
                        )).collect(Collectors.toList())
                    );
                }
                return null;
            })
            .filter(map -> map != null)
            .collect(Collectors.toList());
    }

    @Transactional
    public int notifyUsersWithExpiringPlans() {
        List<RechargeHistory> allRecharges = rechargeHistoryRepository.findAll();
        LocalDateTime now = LocalDateTime.now();
        int newNotifiedCount = 0;

        logger.info("Starting notification process for expiring plans...");

        for (RechargeHistory recharge : allRecharges) {
            LocalDateTime expiryDate = recharge.getExpiryDate();
            long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(now, expiryDate);

            logger.info("Checking record: ID={}, Email={}, Expiry={}, Days Left={}, Notified={}",
                    recharge.getId(), recharge.getEmail(), expiryDate, daysLeft, recharge.isNotified());

            if (daysLeft >= 0 && daysLeft <= 3 && !recharge.isNotified()) {
                if (recharge.getEmail() == null || recharge.getEmail().trim().isEmpty()) {
                    logger.warn("Skipping notification for ID={} due to missing email", recharge.getId());
                    continue;
                }

                try {
                    emailService.sendExpiryNotificationEmail(recharge.getEmail(), recharge, (int) daysLeft);
                    recharge.setNotified(true);
                    rechargeHistoryRepository.save(recharge);
                    newNotifiedCount++;
                    logger.info("Notification sent for ID={}", recharge.getId());
                } catch (Exception e) {
                    logger.error("Failed to send notification to ID={}, Email={}: {}",
                            recharge.getId(), recharge.getEmail(), e.getMessage());
                }
            }
        }

        int totalNotified = (int) rechargeHistoryRepository.findAll().stream()
                .filter(RechargeHistory::isNotified)
                .count();

        logger.info("Notification process completed. New notifications sent: {}, Total notified users: {}",
                newNotifiedCount, totalNotified);

        return totalNotified;
    }

    public List<RechargeHistory> getExpiringPlans(int days) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime threshold = now.plusDays(days);
        return rechargeHistoryRepository.findAll().stream()
                .filter(recharge -> recharge.getExpiryDate().isAfter(now) &&
                        recharge.getExpiryDate().isBefore(threshold))
                .collect(Collectors.toList());
    }
}
