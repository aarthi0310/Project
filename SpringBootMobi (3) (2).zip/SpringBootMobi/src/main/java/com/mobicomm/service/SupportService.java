package com.mobicomm.service;

import com.mobicomm.entity.SupportTicket;
import com.mobicomm.entity.User;
import com.mobicomm.repository.SupportTicketRepository;
import com.mobicomm.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Service
public class SupportService {

    private static final Logger logger = LoggerFactory.getLogger(SupportService.class);

    @Autowired
    private SupportTicketRepository ticketRepository;

    @Autowired
    private UserRepository userRepository;

    public SupportTicket createTicket(SupportTicket ticket) {
        // Validate empty fields
        if (ticket.getCustomerName() == null || ticket.getCustomerName().trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty");
        }
        if (ticket.getMobile() == null || ticket.getMobile().trim().isEmpty()) {
            throw new IllegalArgumentException("Mobile number cannot be empty");
        }
        if (ticket.getIssueType() == null || ticket.getIssueType().trim().isEmpty()) {
            throw new IllegalArgumentException("Issue type cannot be empty");
        }
        if (ticket.getDescription() == null || ticket.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty");
        }

        // Extract and validate phone number (expecting 10 digits, no prefix required)
        String phoneNumber = ticket.getMobile().trim();
        if (!phoneNumber.matches("^\\d{10}$")) {
            throw new IllegalArgumentException("Invalid mobile number format. Must be 10 digits.");
        }

        // Check if phone number exists in User table (stored without +91 prefix)
        User user = userRepository.findByPhoneNumber(phoneNumber).orElse(null);
        if (user == null) {
            throw new IllegalArgumentException("Please enter a valid Mobi-Comm number");
        }

        // Populate customer name from User if available
        ticket.setCustomerName(user.getName());
        // Store mobile as received (10 digits, no prefix) to match DB format
        ticket.setMobile(phoneNumber);

        // Generate ticket ID
        String ticketId = "TKT-2025-" + new Random().nextInt(9000) + 1000;
        ticket.setTicketId(ticketId);

        // Set initial values
        LocalDateTime now = LocalDateTime.now();
        ticket.setSubmittedDate(now);
        ticket.setLastUpdated(now);
        ticket.setStatus("New");
        ticket.setPriority("Medium");
        ticket.setAssignedTo("Unassigned");

        // Add initial communication
        SupportTicket.Communication initialComm = new SupportTicket.Communication();
        initialComm.setSender("System");
        initialComm.setTimestamp(now);
        initialComm.setMessage("Ticket created and assigned to support team.");
        ticket.getCommunication().add(initialComm);

        logger.info("Creating new support ticket: {}", ticketId);
        return ticketRepository.save(ticket);
    }

    public List<SupportTicket> getAllTickets() {
        logger.info("Fetching all support tickets");
        return ticketRepository.findAll();
    }

    public SupportTicket getTicketById(String ticketId) {
        logger.info("Fetching ticket with ID: {}", ticketId);
        return ticketRepository.findByTicketId(ticketId);
    }
}