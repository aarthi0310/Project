package com.mobicomm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ExpiryNotificationScheduler {

    @Autowired
    private UserService userService;

    // Runs every day at midnight (configurable via cron expression)
    @Scheduled(cron = "0 0 0 * * ?") // Cron: second, minute, hour, day, month, weekday
    public void checkAndNotifyExpiringPlans() {
        userService.notifyUsersWithExpiringPlans();
    }
}