package com.mobicomm.controller;

import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recharge")
@CrossOrigin(origins = "*")
public class RechargeController {
    private static final Logger logger = LoggerFactory.getLogger(RechargeController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/history/{phoneNumber}")
    public ResponseEntity<List<RechargeHistory>> getRechargeHistory(@PathVariable String phoneNumber) {
        logger.info("Fetching recharge history for phone number: {}", phoneNumber);
        List<RechargeHistory> history = userService.getRechargeHistoryByPhoneNumber(phoneNumber);
        logger.info("Recharge history fetched: {}", history);
        return ResponseEntity.ok(history);
    }

    @GetMapping("/history/all")
    public ResponseEntity<List<Map<String, Object>>> getAllRechargeHistory() {
        logger.info("Fetching all grouped recharge history records");
        List<Map<String, Object>> allHistory = userService.getGroupedRechargeHistory();
        logger.info("All grouped recharge history fetched: {}", allHistory);
        return ResponseEntity.ok(allHistory);
    }

    // New endpoint to fetch expiring plans
    @GetMapping("/expiring")
    public ResponseEntity<List<RechargeHistory>> getExpiringPlans(
            @RequestParam(value = "days", defaultValue = "7") int days) {
        logger.info("Fetching recharge records expiring within {} days", days);
        List<RechargeHistory> expiringPlans = userService.getExpiringPlans(days);
        logger.info("Expiring plans fetched: {}", expiringPlans);
        return ResponseEntity.ok(expiringPlans);
    }
 
}