package com.mobicomm.controller;


import com.mobicomm.dto.PhoneNumberRequest;
import com.mobicomm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/validate-phone")
    public ResponseEntity<?> validatePhone(@RequestBody PhoneNumberRequest request) {
        String phoneNumber = request.getPhoneNumber();
        if (phoneNumber == null || !phoneNumber.matches("\\d{10}")) {
            return ResponseEntity.badRequest().body(Map.of("error", "Please enter a valid 10-digit number"));
        }
        boolean isRegistered = userService.isRegisteredUser(phoneNumber);
        if (isRegistered) {
            return ResponseEntity.ok(Map.of("redirectUrl", "http://127.0.0.1:5501/customer/plans.html", "phoneNumber", phoneNumber));
        } else {
            return ResponseEntity.badRequest().body(Map.of("error", "Please enter a valid Mobi-Comm number"));
        }
    }
}