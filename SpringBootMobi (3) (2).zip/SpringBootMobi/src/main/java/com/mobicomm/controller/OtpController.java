package com.mobicomm.controller;

import com.mobicomm.model.OtpRequest;
import com.mobicomm.service.OtpService;
import com.mobicomm.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class OtpController {

    @Autowired
    private OtpService otpService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/send-otp")
    public ResponseEntity<?> sendOtp(@RequestBody OtpRequest request) {
        try {
            if (request.getPhoneNumber() == null) {
                return ResponseEntity.badRequest().body("Phone number is required.");
            }
            String phoneNumber = request.getPhoneNumber().replaceAll("\\s+", "");
            if (!phoneNumber.matches("^\\+\\d{11,12}$")) {
                return ResponseEntity.badRequest().body("Invalid phone number format. Must be in the format +91XXXXXXXXXX (10 digits after country code).");
            }
            otpService.sendOtp(phoneNumber);
            return ResponseEntity.ok("OTP sent successfully.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            System.err.println("Error in sendOtp: " + e.getMessage());
            return ResponseEntity.status(500).body("Failed to send OTP: " + e.getMessage());
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody OtpRequest request) {
        System.out.println("Received /api/verify-otp request: " + request);
        if (request.getPhoneNumber() == null || request.getOtp() == null) {
            return ResponseEntity.badRequest().body("Phone number and OTP are required.");
        }
        String phoneNumber = request.getPhoneNumber().replaceAll("\\s+", "");
        boolean isValid = otpService.verifyOtp(phoneNumber, request.getOtp());
        if (isValid) {
            try {
                String token = jwtUtil.generateToken(phoneNumber);
                System.out.println("Generated JWT Token: " + token);
                return ResponseEntity.ok(Map.of(
                    "message", "OTP verified successfully.",
                    "token", token,
                    "redirectUrl", "/customer/plans1.html?phone=" + phoneNumber.replace("+91", "")
                ));
            } catch (Exception e) {
                System.err.println("Error generating JWT token: " + e.getMessage());
                return ResponseEntity.status(500).body("Failed to generate token: " + e.getMessage());
            }
        } else {
            return ResponseEntity.badRequest().body("Invalid or expired OTP.");
        }
    }
}