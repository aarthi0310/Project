package com.mobicomm.controller;

import com.mobicomm.dto.PlanAnalytics;
import com.mobicomm.model.Plan;
import com.mobicomm.repository.PlanRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/plans")
@CrossOrigin(origins = "*")
public class PlanController {
    @Autowired
    private PlanRepository planRepository;

    @GetMapping
    public ResponseEntity<Page<Plan>> getAllPlans(
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "5") int size,
            @RequestParam(value = "search", required = false, defaultValue = "") String search,
            @RequestParam(value = "category", required = false, defaultValue = "") String category,
            @RequestParam(value = "status", required = false, defaultValue = "") String status) {
        List<Plan> allPlans = planRepository.findAll();

        List<Plan> filteredPlans = allPlans.stream()
            .filter(plan -> search.isEmpty() || plan.getName().toLowerCase().contains(search.toLowerCase()))
            .filter(plan -> category.isEmpty() || plan.getCategory().equals(category))
            .filter(plan -> status.isEmpty() || 
                (status.equals("active") && plan.isActive()) || 
                (status.equals("inactive") && !plan.isActive()))
            .collect(Collectors.toList());

        int start = Math.min(page * size, filteredPlans.size());
        int end = Math.min(start + size, filteredPlans.size());
        List<Plan> paginatedPlans = filteredPlans.subList(start, end);
        Pageable pageable = PageRequest.of(page, size);
        Page<Plan> filteredPage = new PageImpl<>(paginatedPlans, pageable, filteredPlans.size());
        return ResponseEntity.ok(filteredPage);
    }

    // Add this new endpoint to fetch a plan by ID
    @GetMapping("/{id}")
    public ResponseEntity<Plan> getPlanById(@PathVariable Long id) {
        return planRepository.findById(id)
            .map(plan -> ResponseEntity.ok(plan))
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/analytics")
    public ResponseEntity<PlanAnalytics> getPlanAnalytics() {
        List<Plan> plans = planRepository.findAll();
        List<Plan> activePlans = plans.stream()
            .filter(Plan::isActive)
            .collect(Collectors.toList());
        int totalPlans = plans.size();
        int activePlansCount = activePlans.size();
        double averagePrice = activePlansCount > 0 ?
            activePlans.stream().mapToDouble(Plan::getPrice).average().getAsDouble() : 0.0;
        PlanAnalytics analytics = new PlanAnalytics(totalPlans, activePlansCount, averagePrice);
        return ResponseEntity.ok(analytics);
    }

    @GetMapping("/export-csv")
    public ResponseEntity<String> exportPlansAsCsv(
            @RequestParam(value = "search", required = false, defaultValue = "") String search,
            @RequestParam(value = "category", required = false, defaultValue = "") String category,
            @RequestParam(value = "status", required = false, defaultValue = "") String status) {
        List<Plan> plans = planRepository.findAll();

        List<Plan> filteredPlans = plans.stream()
            .filter(plan -> search.isEmpty() || plan.getName().toLowerCase().contains(search.toLowerCase()))
            .filter(plan -> category.isEmpty() || plan.getCategory().equals(category))
            .filter(plan -> status.isEmpty() || 
                (status.equals("active") && plan.isActive()) || 
                (status.equals("inactive") && !plan.isActive()))
            .collect(Collectors.toList());

        if (filteredPlans.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        StringBuilder csvContent = new StringBuilder();
        csvContent.append("ID,Name,Price,Data,Validity,Category,Active\n");
        for (Plan plan : filteredPlans) {
            csvContent.append(String.format("%d,\"%s\",%.2f,\"%s\",\"%s\",\"%s\",%s\n",
                plan.getId(), plan.getName(), plan.getPrice(), plan.getData(),
                plan.getValidity(), plan.getCategory(), plan.isActive() ? "Yes" : "No"));
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        headers.setContentDispositionFormData("attachment", "plans.csv");
        return ResponseEntity.ok().headers(headers).body(csvContent.toString());
    }

    @PostMapping
    @Transactional
    public ResponseEntity<Plan> createPlan(@RequestBody Plan plan) {
        Plan savedPlan = planRepository.save(plan);
        return ResponseEntity.ok(savedPlan);
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<Plan> updatePlan(@PathVariable Long id, @RequestBody Plan planDetails) {
        return planRepository.findById(id)
            .map(plan -> {
                plan.setName(planDetails.getName());
                plan.setPrice(planDetails.getPrice());
                plan.setData(planDetails.getData());
                plan.setValidity(planDetails.getValidity());
                plan.setCategory(planDetails.getCategory());
                plan.setActive(planDetails.isActive());
                Plan updatedPlan = planRepository.save(plan);
                return ResponseEntity.ok(updatedPlan);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deletePlan(@PathVariable Long id) {
        return planRepository.findById(id)
            .map(plan -> {
                planRepository.delete(plan);
                return ResponseEntity.ok().<Void>build();
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/toggle")
    @Transactional
    public ResponseEntity<Plan> togglePlanStatus(@PathVariable Long id) {
        return planRepository.findById(id)
            .map(plan -> {
                plan.setActive(!plan.isActive());
                Plan updatedPlan = planRepository.save(plan);
                return ResponseEntity.ok(updatedPlan);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/bulk-toggle")
    @Transactional
    public ResponseEntity<List<Plan>> bulkTogglePlans(@RequestParam boolean active) {
        List<Plan> plans = planRepository.findAll();
        plans.forEach(plan -> plan.setActive(active));
        List<Plan> updatedPlans = planRepository.saveAll(plans);
        return ResponseEntity.ok(updatedPlans);
    }
}