package com.mobicomm.config;

import com.mobicomm.util.JwtUtil;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    public JwtAuthenticationFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        String token = null;
        String phoneNumber = null;

        System.out.println("Request URL: " + request.getRequestURL());
        System.out.println("Authorization Header: " + header);

        if (header != null && header.startsWith("Bearer ")) {
            token = header.substring(7);
            System.out.println("JWT Token: " + token);
            try {
                phoneNumber = jwtUtil.extractPhoneNumber(token);
                System.out.println("Extracted Phone Number: " + phoneNumber);
            } catch (Exception e) {
                System.err.println("Error extracting phone number from token: " + e.getMessage());
            }
        } else {
            System.err.println("Authorization header missing or does not start with Bearer");
        }

        if (phoneNumber != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            if (jwtUtil.validateToken(token)) {
                System.out.println("JWT Token validated successfully");
                UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                        phoneNumber, null, null);
                auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(auth);
            } else {
                System.err.println("JWT token validation failed for token: " + token);
            }
        } else if (phoneNumber == null && token != null) {
            System.err.println("Could not extract phone number from token: " + token);
        }

        filterChain.doFilter(request, response);
    }
}