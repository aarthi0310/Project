package com.mobicomm.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "recharge_history")
@Data
public class RechargeHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String name;
    private String phoneNumber;
    private String planName;
    private Double amount;
    private String paymentMethod;
    private String transactionId;
    private LocalDateTime rechargeDate;
    private LocalDateTime expiryDate;
    private String email;

    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean notified = false; // New field to track if notified
}