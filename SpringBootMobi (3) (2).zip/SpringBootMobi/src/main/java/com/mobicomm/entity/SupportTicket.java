package com.mobicomm.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "support_tickets")
@Data
public class SupportTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ticket_id", unique = true)
    private String ticketId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "issue_type")
    private String issueType;

    @Column(name = "issue_type_name")
    private String issueTypeName;

    @Column(name = "description")
    private String description;

    @Column(name = "submitted_date")
    private LocalDateTime submittedDate;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Column(name = "status")
    private String status;

    @Column(name = "priority")
    private String priority;

    @Column(name = "assigned_to")
    private String assignedTo;

    @Column(name = "plan")
    private String plan;

    @Column(name = "customer_since")
    private String customerSince;

    @ElementCollection
    @CollectionTable(name = "ticket_communication", joinColumns = @JoinColumn(name = "ticket_id"))
    private List<Communication> communication = new ArrayList<>();

    @Embeddable
    @Data
    public static class Communication {
        private String sender;
        private LocalDateTime timestamp;
        private String message;
    }
}