package com.mobicomm.model;

import lombok.Data;

@Data
public class OtpRequest {
    private String phoneNumber;
    private String otp;
}