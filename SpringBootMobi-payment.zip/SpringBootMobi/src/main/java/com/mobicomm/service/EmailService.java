package com.mobicomm.service;

import com.mobicomm.entity.RechargeHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Async
    public void sendRechargeConfirmationEmail(String toEmail, RechargeHistory recharge) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Mobi-Comm Recharge Confirmation");
        message.setText(buildEmailBody(recharge));
        message.setFrom(fromEmail);

        mailSender.send(message);
    }

    private String buildEmailBody(RechargeHistory recharge) {
        return "Dear Customer,\n\n" +
               "Your recharge has been successfully completed!\n\n" +
               "Recharge Details:\n" +
               "Plan Name: " + recharge.getPlanName() + "\n" +
               "Amount: ₹" + recharge.getAmount() + "\n" +
               "Payment Method: " + recharge.getPaymentMethod() + "\n" +
               "Transaction ID: " + recharge.getTransactionId() + "\n" +
               "Recharge Date: " + recharge.getRechargeDate() + "\n" +
               "Expiry Date: " + recharge.getExpiryDate() + "\n\n" +
               "Thank you for choosing Mobi-Comm!\n" +
               "For support, contact: support@mobi-comm.com\n\n" +
               "Best Regards,\n" +
               "Mobi-Comm Team";
    }
}