package com.mobicomm.service;

import com.mobicomm.dto.PaymentConfirmationRequest;
import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.entity.User;
import com.mobicomm.repository.RechargeHistoryRepository;
import com.mobicomm.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RechargeHistoryRepository rechargeHistoryRepository;
    
    @Autowired
    private EmailService emailService;

    public boolean isRegisteredUser(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber).isPresent();
    }

    public boolean transactionExists(String transactionId) {
        return rechargeHistoryRepository.findByTransactionId(transactionId).isPresent();
    }

    @Transactional
    public void saveRechargeHistory(PaymentConfirmationRequest request) {
        Optional<User> userOptional = userRepository.findByPhoneNumber(request.getPhoneNumber());
        if (!userOptional.isPresent()) {
            throw new RuntimeException("User not found with phone number: " + request.getPhoneNumber());
        }

        User user = userOptional.get();
        
        if (rechargeHistoryRepository.findByTransactionId(request.getTransactionId()).isPresent()) {
            throw new RuntimeException("Transaction " + request.getTransactionId() + " already processed");
        }

        String validity = request.getValidity();
        int days = Integer.parseInt(validity.split(" ")[0]);
        LocalDateTime expiryDate = LocalDateTime.now().plusDays(days);

        RechargeHistory recharge = new RechargeHistory();
        recharge.setUser(user);
        recharge.setPhoneNumber(user.getPhoneNumber());
        recharge.setPlanName(request.getPlanName());
        recharge.setAmount(request.getAmount());
        recharge.setPaymentMethod(request.getPaymentMethod());
        recharge.setTransactionId(request.getTransactionId());
        recharge.setRechargeDate(LocalDateTime.now());
        recharge.setExpiryDate(expiryDate);
        recharge.setEmail(user.getEmail());

        RechargeHistory savedRecharge = rechargeHistoryRepository.save(recharge);
        emailService.sendRechargeConfirmationEmail(savedRecharge.getEmail(), savedRecharge);
    }
}