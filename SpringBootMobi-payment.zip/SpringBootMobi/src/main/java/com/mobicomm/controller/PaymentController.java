package com.mobicomm.controller;

import com.mobicomm.dto.PaymentConfirmationRequest;
import com.mobicomm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin(origins = "*")
public class PaymentController {
    
    @Autowired
    private UserService userService;

    @PostMapping("/confirm")
    public ResponseEntity<?> confirmPayment(@RequestBody PaymentConfirmationRequest request) {
        try {
            if (userService.transactionExists(request.getTransactionId())) {
                return ResponseEntity.status(400)
                    .body(Map.of("error", "Transaction already processed"));
            }

            userService.saveRechargeHistory(request);
            return ResponseEntity.ok(Map.of(
                "message", "Payment confirmed and recharge history saved",
                "transactionId", request.getTransactionId(),
                "phoneNumber", request.getPhoneNumber()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(500)
                .body(Map.of("error", "Failed to process payment: " + e.getMessage()));
        }
    }
}