package com.mobicomm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = {"com.mobicomm.model", "com.mobicomm.entity"}) 
@EnableJpaRepositories(basePackages = "com.mobicomm.repository")
public class SpringBootDemoPlans1Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootDemoPlans1Application.class, args);
    }
}