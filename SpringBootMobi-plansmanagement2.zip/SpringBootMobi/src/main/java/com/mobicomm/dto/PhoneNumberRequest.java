package com.mobicomm.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PhoneNumberRequest {
    private String phoneNumber;
}