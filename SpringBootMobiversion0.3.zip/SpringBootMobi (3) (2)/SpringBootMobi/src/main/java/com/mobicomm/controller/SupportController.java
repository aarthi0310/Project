package com.mobicomm.controller;

import com.mobicomm.entity.SupportTicket;
import com.mobicomm.service.SupportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/support")
@CrossOrigin(origins = "*") // Adjust for production
public class SupportController {

    private static final Logger logger = LoggerFactory.getLogger(SupportController.class);

    @Autowired
    private SupportService supportService;

    @PostMapping("/submit")
    public ResponseEntity<?> submitTicket(@RequestBody SupportTicket ticket) {
        try {
            logger.info("Received support ticket submission from: {}", ticket.getCustomerName());
            SupportTicket createdTicket = supportService.createTicket(ticket);
            return ResponseEntity.ok(createdTicket);
        } catch (IllegalArgumentException e) {
            logger.error("Validation error: {}", e.getMessage());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        } catch (Exception e) {
            logger.error("Unexpected error: {}", e.getMessage(), e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "An unexpected error occurred");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/tickets")
    public ResponseEntity<List<SupportTicket>> getAllTickets() {
        logger.info("Request received to fetch all tickets");
        List<SupportTicket> tickets = supportService.getAllTickets();
        return ResponseEntity.ok(tickets);
    }

    @GetMapping("/ticket/{ticketId}")
    public ResponseEntity<SupportTicket> getTicketById(@PathVariable String ticketId) {
        logger.info("Request received to fetch ticket: {}", ticketId);
        SupportTicket ticket = supportService.getTicketById(ticketId);
        if (ticket != null) {
            return ResponseEntity.ok(ticket);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}