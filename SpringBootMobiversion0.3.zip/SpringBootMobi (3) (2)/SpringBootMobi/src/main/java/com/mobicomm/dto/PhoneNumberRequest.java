package com.mobicomm.dto;

public class PhoneNumberRequest {
    private String phoneNumber;

    public PhoneNumberRequest() {} // Ensure default constructor is present

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}