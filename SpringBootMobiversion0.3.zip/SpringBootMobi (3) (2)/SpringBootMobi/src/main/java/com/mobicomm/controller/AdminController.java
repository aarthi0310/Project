package com.mobicomm.controller;

import com.mobicomm.model.Admin;
import com.mobicomm.repository.AdminRepository;
import com.mobicomm.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://127.0.0.1:5501")
public class AdminController {
    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody Admin loginRequest) {
        Admin admin = adminRepository.findByAdminName(loginRequest.getAdminName()).orElse(null);
        Map<String, String> response = new HashMap<>();

        if (admin != null && passwordEncoder.matches(loginRequest.getPassword(), admin.getPassword())) {
            String token = jwtUtil.generateToken(admin.getAdminName());
            response.put("token", token);
            response.put("message", "Login successful");
            response.put("redirectUrl", "/admin/plansmanagement.html"); // Adjust as needed
            return ResponseEntity.ok(response);
        }

        response.put("error", "Invalid credentials");
        return ResponseEntity.status(401).body(response);
    }
}