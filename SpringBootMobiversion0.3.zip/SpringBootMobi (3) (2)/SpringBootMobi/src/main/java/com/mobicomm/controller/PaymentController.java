package com.mobicomm.controller;

import com.mobicomm.dto.PaymentConfirmationRequest;
import com.mobicomm.service.UserService;
import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    @Autowired
    private UserService userService;

    // Create Razorpay Order
    @PostMapping("/create")
    public ResponseEntity<?> createRazorpayOrder(@RequestBody Map<String, Object> request) {
        try {
            Integer amount = (Integer) request.get("amount");
            if (amount == null || amount < 100) {
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid amount. Minimum is 100 paise."));
            }

            String phoneNumber = String.valueOf(request.get("phoneNumber"));
            if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Phone number is required."));
            }

            String planName = String.valueOf(request.get("planName"));
            String validity = String.valueOf(request.get("validity"));

            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amount);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "order_rcptid_" + phoneNumber);
            orderRequest.put("payment_capture", 1);

            Order order = razorpay.orders.create(orderRequest);

            Map<String, Object> response = new HashMap<>();
            response.put("orderId", order.get("id"));
            response.put("amount", amount);
            response.put("currency", "INR");
            response.put("key", razorpayKeyId);
            response.put("phoneNumber", phoneNumber);
            response.put("planName", planName);
            response.put("validity", validity);
            response.put("paymentMethod", "Razorpay");

            return ResponseEntity.ok(response);
        } catch (RazorpayException e) {
            return ResponseEntity.status(500).body(Map.of("error", "Failed to create Razorpay order: " + e.getMessage()));
        } catch (ClassCastException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid amount format: " + e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", "Internal server error: " + e.getMessage()));
        }
    }

    // Verify Payment and Save to Recharge History
 // PaymentController.java
    @PostMapping("/verify")
    public ResponseEntity<?> verifyPaymentAndSave(@RequestBody Map<String, String> paymentResponse) throws RazorpayException {
        String razorpayPaymentId = paymentResponse.get("razorpay_payment_id");
        String razorpayOrderId = paymentResponse.get("razorpay_order_id");
        String razorpaySignature = paymentResponse.get("razorpay_signature");
        String phoneNumber = paymentResponse.get("phoneNumber"); // Ensure this is passed from frontend
        String planName = paymentResponse.get("planName");
        String amountStr = paymentResponse.get("amount"); // Amount in paise
        String validity = paymentResponse.get("validity");

        // Verify payment with Razorpay
        RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
        Payment payment = razorpay.payments.fetch(razorpayPaymentId);

        // Check if payment is successful
        if (!"captured".equals(payment.get("status"))) {
            return ResponseEntity.badRequest().body("Payment failed or not captured.");
        }

        // Get phone number from Razorpay payment if available (override if provided)
        String razorpayPhone = payment.get("contact") != null ? payment.get("contact").toString() : phoneNumber;
        if (razorpayPhone != null && !razorpayPhone.equals(phoneNumber)) {
            phoneNumber = razorpayPhone; // Use Razorpay-provided phone number if different
        }

        // Convert amount from paise to rupees
        Double amount = Double.parseDouble(amountStr) / 100;

        // Prepare PaymentConfirmationRequest
        PaymentConfirmationRequest confirmationRequest = new PaymentConfirmationRequest();
        confirmationRequest.setPhoneNumber(phoneNumber);
        confirmationRequest.setPlanName(planName);
        confirmationRequest.setAmount(amount);
        confirmationRequest.setPaymentMethod("Razorpay");
        confirmationRequest.setTransactionId(razorpayPaymentId);
        confirmationRequest.setValidity(validity);

        // Save to RechargeHistory
        try {
            userService.saveRechargeHistory(confirmationRequest);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to save recharge history: " + e.getMessage());
        }

        // Prepare response for frontend redirection with all details
        Map<String, String> response = new HashMap<>();
        response.put("phoneNumber", phoneNumber); // Exact phone number from Razorpay or request
        response.put("planName", planName);
        response.put("amount", amount.toString());
        response.put("method", "Razorpay");
        response.put("transactionId", razorpayPaymentId);
        response.put("date", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        response.put("validity", validity);
        response.put("redirectUrl", "http://127.0.0.1:5501/customer/paymentconformation.html");

        return ResponseEntity.ok(response);
    }
}