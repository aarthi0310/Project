package com.mobicomm.model;

import lombok.Data;

@Data
public class EmailUpdateRequest {
    private String email;
}