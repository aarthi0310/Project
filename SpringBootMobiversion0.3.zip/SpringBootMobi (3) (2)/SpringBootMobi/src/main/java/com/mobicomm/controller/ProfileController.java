package com.mobicomm.controller;

import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.model.EmailUpdateRequest;
import com.mobicomm.repository.RechargeHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    @Autowired
    private RechargeHistoryRepository rechargeHistoryRepository;

    // Fetch the latest recharge history for a user based on phone number
    @GetMapping("/{phoneNumber}")
    public ResponseEntity<?> getProfile(@PathVariable String phoneNumber) {
        try {
            // Remove any spaces and the country code (+91) for consistency
            String strippedNumber = phoneNumber.replaceAll("\\s+", "").trim();
            if (strippedNumber.startsWith("+91")) {
                strippedNumber = strippedNumber.substring(3); // Remove the "+91" prefix
            }
            System.out.println("Fetching profile for phone number: " + strippedNumber);
            Optional<RechargeHistory> rechargeHistory = rechargeHistoryRepository.findTopByPhoneNumberOrderByRechargeDateDesc(strippedNumber);

            if (rechargeHistory.isPresent()) {
                System.out.println("Found recharge history: " + rechargeHistory.get());
                return ResponseEntity.ok(rechargeHistory.get());
            } else {
                System.out.println("No recharge history found for phone number: " + phoneNumber);
                return ResponseEntity.badRequest().body("No recharge history found for phone number: " + phoneNumber);
            }
        } catch (Exception e) {
            System.err.println("Error fetching profile: " + e.getMessage());
            return ResponseEntity.status(500).body("Failed to fetch profile: " + e.getMessage());
        }
    }

    // Update the email for a user based on phone number
    @PutMapping("/{phoneNumber}/email")
    public ResponseEntity<?> updateEmail(@PathVariable String phoneNumber, @RequestBody EmailUpdateRequest request) {
        try {
            // Remove any spaces and the country code (+91) for consistency
            String strippedNumber = phoneNumber.replaceAll("\\s+", "").trim();
            if (strippedNumber.startsWith("+91")) {
                strippedNumber = strippedNumber.substring(3); // Remove the "+91" prefix
            }
            System.out.println("Updating email for phone number: " + strippedNumber);
            Optional<RechargeHistory> rechargeHistory = rechargeHistoryRepository.findTopByPhoneNumberOrderByRechargeDateDesc(strippedNumber);

            if (rechargeHistory.isPresent()) {
                // Validate the email field
                if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
                    return ResponseEntity.badRequest().body("Email cannot be null or empty.");
                }
                RechargeHistory history = rechargeHistory.get();
                history.setEmail(request.getEmail().trim());
                rechargeHistoryRepository.save(history);
                System.out.println("Email updated for phone number: " + strippedNumber);
                return ResponseEntity.ok("Email updated successfully.");
            } else {
                System.out.println("No recharge history found for phone number: " + phoneNumber);
                return ResponseEntity.badRequest().body("No recharge history found for phone number: " + phoneNumber);
            }
        } catch (Exception e) {
            System.err.println("Error updating email: " + e.getMessage());
            return ResponseEntity.status(500).body("Failed to update email: " + e.getMessage());
        }
    }
}