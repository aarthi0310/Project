package com.mobicomm.controller;

import com.mobicomm.dto.PhoneNumberRequest;
import com.mobicomm.repository.UserRepository;
import com.mobicomm.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;
    @PostMapping("/validate-phone")
    public ResponseEntity<?> validatePhone(@RequestBody PhoneNumberRequest request) {
        logger.info("Received validate-phone request: {}", request);

        if (request == null || request.getPhoneNumber() == null) {
            logger.warn("Request or phoneNumber is null");
            return ResponseEntity.badRequest().body(Map.of("error", "Phone number is required"));
        }

        String phoneNumber = request.getPhoneNumber().trim();
        logger.info("Processing phone number: {}", phoneNumber);

        if (!phoneNumber.matches("^(\\+91)?\\d{10}$")) {
            logger.warn("Invalid phone number format: {}", phoneNumber);
            return ResponseEntity.badRequest().body(Map.of("error", "Please enter a valid 10-digit number (e.g., 1234567890 or +911234567890)"));
        }

        String sanitizedPhoneNumber = phoneNumber.startsWith("+91") ? phoneNumber.substring(3) : phoneNumber;
        logger.info("Sanitized phone number: {}", sanitizedPhoneNumber);

        boolean isRegistered = userService.isRegisteredUser(sanitizedPhoneNumber);
        logger.info("Is phone number registered: {}", isRegistered);

        if (isRegistered) {
            return ResponseEntity.ok(Map.of(
                "redirectUrl", "http://127.0.0.1:5501/customer/plans.html",
                "phoneNumber", sanitizedPhoneNumber
            ));
        } else {
            logger.warn("Phone number not registered: {}", sanitizedPhoneNumber);
            return ResponseEntity.badRequest().body(Map.of("error", "Please enter a valid Mobi-Comm number"));
        }
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> getUserCount() {
        long count = userRepository.count();
        return ResponseEntity.ok(Map.of("count", count));
    }

  }