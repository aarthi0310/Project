package com.mobicomm.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlanAnalytics {
    private int totalPlans;
    private int activePlans;
    private double averagePrice;
}