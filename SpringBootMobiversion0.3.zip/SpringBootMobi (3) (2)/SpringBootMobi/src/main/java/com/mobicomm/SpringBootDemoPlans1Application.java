package com.mobicomm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EntityScan(basePackages = {"com.mobicomm.model", "com.mobicomm.entity"})
@EnableJpaRepositories(basePackages = "com.mobicomm.repository")
@EnableAsync
@EnableScheduling
public class SpringBootDemoPlans1Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootDemoPlans1Application.class, args);
    }
}