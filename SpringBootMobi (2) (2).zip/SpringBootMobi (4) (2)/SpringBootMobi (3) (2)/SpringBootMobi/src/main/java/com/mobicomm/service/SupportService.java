package com.mobicomm.service;

import com.mobicomm.dto.SupportReplyRequest;
import com.mobicomm.entity.SupportTicket;
import com.mobicomm.entity.User;
import com.mobicomm.repository.SupportTicketRepository;
import com.mobicomm.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Service
public class SupportService {

    private static final Logger logger = LoggerFactory.getLogger(SupportService.class);

    @Autowired
    private SupportTicketRepository ticketRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JavaMailSender mailSender;

    public SupportTicket createTicket(SupportTicket ticket) {
        logger.info("Creating ticket for customer: {}", ticket.getCustomerName());
        if (ticket.getCustomerName() == null || ticket.getCustomerName().trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty");
        }
        if (ticket.getMobile() == null || ticket.getMobile().trim().isEmpty()) {
            throw new IllegalArgumentException("Mobile number cannot be empty");
        }
        if (ticket.getIssueType() == null || ticket.getIssueType().trim().isEmpty()) {
            throw new IllegalArgumentException("Issue type cannot be empty");
        }
        if (ticket.getDescription() == null || ticket.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty");
        }

        String phoneNumber = ticket.getMobile().trim();
        if (!phoneNumber.matches("^\\d{10}$")) {
            throw new IllegalArgumentException("Invalid mobile number format. Must be 10 digits.");
        }

        User user = userRepository.findByPhoneNumber(phoneNumber).orElse(null);
        if (user == null) {
            throw new IllegalArgumentException("Please enter a valid Mobi-Comm number");
        }

        ticket.setCustomerName(user.getName());
        ticket.setMobile(phoneNumber);

        String ticketId = "TKT-2025-" + new Random().nextInt(9000) + 1000;
        ticket.setTicketId(ticketId);

        LocalDateTime now = LocalDateTime.now();
        ticket.setSubmittedDate(now);
        ticket.setLastUpdated(now);
        ticket.setStatus("New");
        ticket.setPriority("Medium");
        // Removed assignedTo field

        SupportTicket.Communication initialComm = new SupportTicket.Communication();
        initialComm.setSender("System");
        initialComm.setTimestamp(now);
        initialComm.setMessage("Ticket created and assigned to support team.");
        ticket.getCommunication().add(initialComm);

        logger.info("Saving new support ticket: {}", ticketId);
        return ticketRepository.save(ticket);
    }

    public List<SupportTicket> getAllTickets() {
        logger.info("Fetching all support tickets");
        return ticketRepository.findAll();
    }

    public SupportTicket getTicketById(String ticketId) {
        logger.info("Fetching ticket with ID: {}", ticketId);
        return ticketRepository.findByTicketId(ticketId);
    }

    public SupportTicket sendReply(SupportReplyRequest replyRequest) throws MessagingException {
        logger.info("Processing reply for ticket ID: {}", replyRequest.getTicketId());
        if (replyRequest.getTicketId() == null || replyRequest.getTicketId().trim().isEmpty()) {
            logger.error("Ticket ID is empty");
            throw new IllegalArgumentException("Ticket ID cannot be empty");
        }
        if (replyRequest.getReplyMessage() == null || replyRequest.getReplyMessage().trim().isEmpty()) {
            logger.error("Reply message is empty");
            throw new IllegalArgumentException("Reply message cannot be empty");
        }
        if (replyRequest.getSender() == null || replyRequest.getSender().trim().isEmpty()) {
            logger.error("Sender is empty");
            throw new IllegalArgumentException("Sender cannot be empty");
        }

        logger.info("Fetching ticket with ID: {}", replyRequest.getTicketId());
        SupportTicket ticket = ticketRepository.findByTicketId(replyRequest.getTicketId());
        if (ticket == null) {
            logger.error("Ticket not found for ID: {}", replyRequest.getTicketId());
            throw new IllegalArgumentException("Ticket not found");
        }

        logger.info("Fetching user by phone number: {}", ticket.getMobile());
        User user = userRepository.findByPhoneNumber(ticket.getMobile()).orElse(null);
        if (user == null) {
            logger.error("User not found for mobile: {}", ticket.getMobile());
            throw new IllegalArgumentException("User not found for mobile: " + ticket.getMobile());
        }
        if (user.getEmail() == null || user.getEmail().trim().isEmpty()) {
            logger.error("User email not found for mobile: {}", ticket.getMobile());
            throw new IllegalArgumentException("User email not found for mobile: " + ticket.getMobile());
        }
        logger.info("User email found: {}", user.getEmail());

        logger.info("Preparing to send email to: {}", user.getEmail());
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(user.getEmail());
        helper.setSubject("Mobi-Comm Support: Update on Ticket " + ticket.getTicketId());
        helper.setText(
            "<h3>Mobi-Comm Support</h3>" +
            "<p>Dear " + ticket.getCustomerName() + ",</p>" +
            "<p>We have an update regarding your support ticket (<strong>" + ticket.getTicketId() + "</strong>):</p>" +
            "<p><strong>Message:</strong> " + replyRequest.getReplyMessage() + "</p>" +
            "<p>This ticket has been closed. If you have further issues, please create a new ticket.</p>" +
            "<p>Please do not reply directly to this email. Contact us through the support portal if needed.</p>" +
            "<p>Best regards,<br>Mobi-Comm Support Team</p>",
            true
        );
        try {
            mailSender.send(message);
            logger.info("Email sent successfully to: {}", user.getEmail());
        } catch (Exception e) {
            logger.error("Failed to send email to {}: {}", user.getEmail(), e.getMessage(), e);
            throw new MessagingException("Failed to send email: " + e.getMessage(), e);
        }

        LocalDateTime now = LocalDateTime.now();
        SupportTicket.Communication comm = new SupportTicket.Communication();
        comm.setSender(replyRequest.getSender());
        comm.setTimestamp(now);
        comm.setMessage(replyRequest.getReplyMessage());
        ticket.getCommunication().add(comm);
        ticket.setLastUpdated(now);
        ticket.setStatus("Closed"); // Set status to Closed after reply

        logger.info("Saving updated ticket: {}", ticket.getTicketId());
        return ticketRepository.save(ticket);
    }
}