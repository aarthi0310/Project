package com.mobicomm.service;

import com.mobicomm.repository.UserRepository;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class OtpService {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.phone.number}")
    private String twilioPhoneNumber;

    @Autowired
    private UserRepository userRepository;

    private final Map<String, OtpData> otpStore = new HashMap<>();

    private static class OtpData {
        String otp;
        long expiryTime;

        OtpData(String otp, long expiryTime) {
            this.otp = otp;
            this.expiryTime = expiryTime;
        }
    }

    private String generateOtp() {
        return String.format("%06d", new Random().nextInt(999999));
    }

    public void sendOtp(String phoneNumber) {
        String strippedNumber = phoneNumber.replaceFirst("^\\+\\d{2}", "");
        System.out.println("Checking if phone number exists: " + strippedNumber);
        if (!userRepository.existsByPhoneNumber(strippedNumber)) {
            System.out.println("Phone number not found in database: " + strippedNumber);
            throw new IllegalArgumentException("Please enter a valid Mobi-Comm number.");
        }
        try {
            System.out.println("Initializing Twilio with SID: " + accountSid);
            Twilio.init(accountSid, authToken);
            String otp = generateOtp();
            otpStore.put(phoneNumber, new OtpData(otp, System.currentTimeMillis() + 30000));

            System.out.println("Sending OTP to: " + phoneNumber + " from: " + twilioPhoneNumber);
            Message message = Message.creator(
                    new PhoneNumber(phoneNumber),
                    new PhoneNumber(twilioPhoneNumber),
                    "Your Mobi-Comm OTP is: " + otp + ". Valid for 30 seconds."
            ).create();
            System.out.println("Twilio Message SID: " + message.getSid());
        } catch (Exception e) {
            System.err.println("Failed to send OTP via Twilio: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to send OTP via Twilio: " + e.getMessage());
        }
    }

    public boolean verifyOtp(String phoneNumber, String otp) {
        OtpData otpData = otpStore.get(phoneNumber);
        System.out.println("Verifying OTP for " + phoneNumber + ": " + otp);
        System.out.println("Stored OTP Data: " + (otpData != null ? otpData.otp + ", Expiry: " + otpData.expiryTime : "null"));
        if (otpData == null || System.currentTimeMillis() > otpData.expiryTime) {
            System.out.println("OTP expired or not found");
            otpStore.remove(phoneNumber);
            return false;
        }
        if (!otpData.otp.equals(otp)) {
            System.out.println("OTP mismatch: Expected " + otpData.otp + ", Got " + otp);
            return false;
        }
        System.out.println("OTP verified successfully");
        otpStore.remove(phoneNumber);
        return true;
    }}