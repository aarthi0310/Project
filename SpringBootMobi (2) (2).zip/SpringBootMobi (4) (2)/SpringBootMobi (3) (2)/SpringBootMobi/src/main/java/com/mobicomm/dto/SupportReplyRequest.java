package com.mobicomm.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SupportReplyRequest {
    private String ticketId;
    private String replyMessage;
    private String sender;
}