package com.mobicomm.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "support_tickets")
@Getter
@Setter
public class SupportTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ticket_id", unique = true)
    private String ticketId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "issue_type")
    private String issueType;

    @Column(name = "issue_type_name")
    private String issueTypeName;

    @Column(name = "description")
    private String description;

    @Column(name = "submitted_date")
    private LocalDateTime submittedDate;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    @Column(name = "status")
    private String status;

    @Column(name = "priority")
    private String priority;

    @ElementCollection
    @CollectionTable(name = "ticket_communications", joinColumns = @JoinColumn(name = "ticket_id"))
    private List<Communication> communication = new ArrayList<>();

    @Getter
    @Setter
    @Embeddable
    public static class Communication {
        private String sender;
        private String message;
        private LocalDateTime timestamp;
    }
}