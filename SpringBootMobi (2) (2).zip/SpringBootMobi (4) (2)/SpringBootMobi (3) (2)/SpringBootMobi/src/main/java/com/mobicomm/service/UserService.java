package com.mobicomm.service;

import com.mobicomm.dto.PaymentConfirmationRequest;
import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.entity.User;
import com.mobicomm.repository.RechargeHistoryRepository;
import com.mobicomm.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.Month;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RechargeHistoryRepository rechargeHistoryRepository;

    @Autowired
    private EmailService emailService;

    public boolean isRegisteredUser(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber).isPresent();
    }

    public boolean transactionExists(String transactionId) {
        return rechargeHistoryRepository.findByTransactionId(transactionId).isPresent();
    }

    @Transactional
    public void saveRechargeHistory(PaymentConfirmationRequest request) {
        String phoneNumber = sanitizePhoneNumber(request.getPhoneNumber());
        logger.info("Saving recharge history for phone number: {}", phoneNumber);

        Optional<User> userOptional = userRepository.findByPhoneNumber(phoneNumber);
        if (!userOptional.isPresent()) {
            logger.error("User not found with phone number: {}", phoneNumber);
            throw new RuntimeException("User not found with phone number: " + phoneNumber);
        }
        User user = userOptional.get();

        if (transactionExists(request.getTransactionId())) {
            logger.warn("Transaction {} already processed", request.getTransactionId());
            throw new RuntimeException("Transaction " + request.getTransactionId() + " already processed");
        }

        int days = parseValidityDays(request.getValidity());
        LocalDateTime expiryDate = LocalDateTime.now().plusDays(days);

        RechargeHistory recharge = new RechargeHistory();
        recharge.setUser(user);
        recharge.setName(user.getName());
        recharge.setPhoneNumber(phoneNumber);
        recharge.setPlanName(request.getPlanName());
        recharge.setAmount(request.getAmount());
        recharge.setPaymentMethod(request.getPaymentMethod());
        recharge.setTransactionId(request.getTransactionId());
        recharge.setRechargeDate(LocalDateTime.now());
        recharge.setExpiryDate(expiryDate);
        recharge.setEmail(user.getEmail());
        recharge.setNotified(false);

        logger.info("Saving recharge history: {}", recharge);
        RechargeHistory savedRecharge = rechargeHistoryRepository.save(recharge);
        logger.info("Recharge history saved with ID: {}", savedRecharge.getId());

        sendConfirmationEmail(savedRecharge);
    }

    private String sanitizePhoneNumber(String phoneNumber) {
        if (phoneNumber.startsWith("+91")) {
            return phoneNumber.substring(3);
        }
        return phoneNumber;
    }

    private int parseValidityDays(String validity) {
        try {
            return Integer.parseInt(validity.split(" ")[0]);
        } catch (Exception e) {
            logger.error("Invalid validity format: {}", validity, e);
            throw new IllegalArgumentException("Invalid validity format: " + validity);
        }
    }

    private void sendConfirmationEmail(RechargeHistory recharge) {
        if (recharge.getEmail() != null && !recharge.getEmail().isEmpty()) {
            try {
                emailService.sendRechargeConfirmationEmail(recharge.getEmail(), recharge);
                logger.info("Sent recharge confirmation email to: {}", recharge.getEmail());
            } catch (Exception e) {
                logger.error("Failed to send email to {}: {}", recharge.getEmail(), e.getMessage());
            }
        } else {
            logger.warn("No email found for user, skipping email notification");
        }
    }

    public List<RechargeHistory> getRechargeHistoryByPhoneNumber(String phoneNumber) {
        return rechargeHistoryRepository.findByPhoneNumber(sanitizePhoneNumber(phoneNumber));
    }

    public List<RechargeHistory> getAllRechargeHistory() {
        return rechargeHistoryRepository.findAll();
    }

    public List<Map<String, Object>> getGroupedRechargeHistory() {
        return rechargeHistoryRepository.findAll().stream()
            .collect(Collectors.groupingBy(RechargeHistory::getPhoneNumber))
            .entrySet().stream()
            .map(entry -> {
                List<RechargeHistory> recharges = entry.getValue();
                RechargeHistory latestRecharge = recharges.stream()
                        .max((r1, r2) -> r1.getRechargeDate().compareTo(r2.getRechargeDate()))
                        .orElse(null);

                if (latestRecharge != null) {
                    Map<String, Object> result = new HashMap<>();
                    result.put("id", latestRecharge.getId());
                    result.put("name", latestRecharge.getName());
                    result.put("phoneNumber", latestRecharge.getPhoneNumber());
                    result.put("planName", latestRecharge.getPlanName());
                    result.put("expiryDate", latestRecharge.getExpiryDate().toString());
                    result.put("notified", latestRecharge.isNotified());

                    List<Map<String, Object>> transactions = recharges.stream()
                        .map(r -> {
                            Map<String, Object> tx = new HashMap<>();
                            tx.put("date", r.getRechargeDate().toString());
                            tx.put("plan", r.getPlanName());
                            tx.put("amount", r.getAmount());
                            tx.put("paymentMode", r.getPaymentMethod());
                            tx.put("status", "Successful");
                            return tx;
                        })
                        .collect(Collectors.toList());
                    result.put("transactions", transactions);

                    return result;
                }
                return null;
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    @Transactional
    public int notifyUsersWithExpiringPlans() {
        List<RechargeHistory> allRecharges = rechargeHistoryRepository.findAll();
        LocalDateTime now = LocalDateTime.now();
        int newNotifiedCount = 0;

        logger.info("Starting notification process for expiring plans...");

        for (RechargeHistory recharge : allRecharges) {
            LocalDateTime expiryDate = recharge.getExpiryDate();
            long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(now, expiryDate);

            logger.info("Checking record: ID={}, Email={}, Expiry={}, Days Left={}, Notified={}",
                    recharge.getId(), recharge.getEmail(), expiryDate, daysLeft, recharge.isNotified());

            if (daysLeft >= 0 && daysLeft <= 3 && !recharge.isNotified()) {
                if (recharge.getEmail() == null || recharge.getEmail().trim().isEmpty()) {
                    logger.warn("Skipping notification for ID={} due to missing email", recharge.getId());
                    continue;
                }

                try {
                    emailService.sendExpiryNotificationEmail(recharge.getEmail(), recharge, (int) daysLeft);
                    recharge.setNotified(true);
                    rechargeHistoryRepository.save(recharge);
                    newNotifiedCount++;
                    logger.info("Notification sent for ID={}", recharge.getId());
                } catch (Exception e) {
                    logger.error("Failed to send notification to ID={}, Email={}: {}",
                            recharge.getId(), recharge.getEmail(), e.getMessage());
                }
            }
        }

        int totalNotified = (int) rechargeHistoryRepository.findAll().stream()
                .filter(RechargeHistory::isNotified)
                .count();

        logger.info("Notification process completed. New notifications sent: {}, Total notified users: {}",
                newNotifiedCount, totalNotified);

        return totalNotified;
    }

    public List<RechargeHistory> getExpiringPlans(int days) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime threshold = now.plusDays(days);
        return rechargeHistoryRepository.findAll().stream()
                .filter(recharge -> recharge.getExpiryDate().isAfter(now) &&
                        recharge.getExpiryDate().isBefore(threshold))
                .collect(Collectors.toList());
    }

    public long getTotalSubscribers() {
        return userRepository.count();
    }

    public Map<String, Object> getRevenueAnalytics() {
        List<RechargeHistory> allRecharges = rechargeHistoryRepository.findAll();

        // Calculate Total Revenue
        double totalRevenue = allRecharges.stream()
            .mapToDouble(RechargeHistory::getAmount)
            .sum();

        // Monthly Revenue (Last 6 months)
        LocalDateTime sixMonthsAgo = LocalDateTime.now().minusMonths(6);
        Map<String, Double> monthlyRevenueMap = allRecharges.stream()
            .filter(r -> r.getRechargeDate().isAfter(sixMonthsAgo))
            .collect(Collectors.groupingBy(
                r -> r.getRechargeDate().getMonth().toString() + " " + r.getRechargeDate().getYear(),
                Collectors.summingDouble(RechargeHistory::getAmount)
            ));

        List<Map<String, Object>> monthlyRevenue = monthlyRevenueMap.entrySet().stream()
            .map(e -> {
                Map<String, Object> map = new HashMap<>();
                map.put("month", e.getKey());
                map.put("revenue", e.getValue());
                return map;
            })
            .sorted(Comparator.comparing(m -> {
                String[] parts = ((String) m.get("month")).split(" ");
                return YearMonth.of(Integer.parseInt(parts[1]), Month.valueOf(parts[0])).atDay(1);
            }))
            .collect(Collectors.toList());

        // Popular Plans
        List<Map<String, Object>> popularPlans = allRecharges.stream()
            .collect(Collectors.groupingBy(
                RechargeHistory::getPlanName,
                Collectors.counting()
            ))
            .entrySet().stream()
            .map(e -> {
                Map<String, Object> map = new HashMap<>();
                map.put("planName", e.getKey());
                map.put("count", e.getValue());
                return map;
            })
            .sorted(Comparator.comparingLong((Map<String, Object> m) -> (Long) m.get("count")).reversed())
            .limit(5)
            .collect(Collectors.toList());

        Map<String, Object> result = new HashMap<>();
        result.put("totalRevenue", totalRevenue);
        result.put("monthlyRevenue", monthlyRevenue);
        result.put("popularPlans", popularPlans);

        return result;
    }
}