package com.mobicomm.repository;

import com.mobicomm.entity.RechargeHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RechargeHistoryRepository extends JpaRepository<RechargeHistory, Long> {

    Optional<RechargeHistory> findByTransactionId(String transactionId);

    List<RechargeHistory> findByPhoneNumber(String phoneNumber);
    
    Optional<RechargeHistory> findTopByPhoneNumberOrderByRechargeDateDesc(String phoneNumber);
}