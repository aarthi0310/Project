package com.mobicomm.controller;

import com.mobicomm.entity.RechargeHistory;
import com.mobicomm.repository.RechargeHistoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recharge")
@CrossOrigin(origins = "*")
public class RechargeController {
    private static final Logger logger = LoggerFactory.getLogger(RechargeController.class);

    @Autowired
    private RechargeHistoryRepository rechargeHistoryRepository;

    @GetMapping("/history/{phoneNumber}")
    public ResponseEntity<List<RechargeHistory>> getRechargeHistory(@PathVariable String phoneNumber) {
        logger.info("Fetching recharge history for phone number: {}", phoneNumber);
        List<RechargeHistory> history = rechargeHistoryRepository.findByPhoneNumber(phoneNumber);
        logger.info("Recharge history fetched: {}", history);
        return ResponseEntity.ok(history);
    }

    @GetMapping("/history/all")
    public ResponseEntity<List<Map<String, Object>>> getAllRechargeHistory() {
        logger.info("Fetching all grouped recharge history records");
        List<Map<String, Object>> allHistory = rechargeHistoryRepository.findAll().stream()
            .collect(Collectors.groupingBy(RechargeHistory::getPhoneNumber))
            .entrySet().stream()
            .map(entry -> {
                List<RechargeHistory> recharges = entry.getValue();
                RechargeHistory latest = recharges.stream()
                    .max((r1, r2) -> r1.getRechargeDate().compareTo(r2.getRechargeDate()))
                    .orElse(null);
                if (latest != null) {
                    return Map.of(
                        "id", latest.getId(),
                        "name", latest.getName(),
                        "phoneNumber", latest.getPhoneNumber(),
                        "planName", latest.getPlanName(),
                        "expiryDate", latest.getExpiryDate().toString(),
                        "notified", latest.isNotified(),
                        "transactions", recharges.stream().map(r -> Map.of(
                            "date", r.getRechargeDate().toString(),
                            "plan", r.getPlanName(),
                            "amount", r.getAmount(),
                            "paymentMode", r.getPaymentMethod(),
                            "status", "Successful"
                        )).collect(Collectors.toList())
                    );
                }
                return null;
            })
            .filter(map -> map != null)
            .collect(Collectors.toList());
        logger.info("All grouped recharge history fetched: {}", allHistory);
        return ResponseEntity.ok(allHistory);
    }

    @GetMapping("/expiring")
    public ResponseEntity<List<RechargeHistory>> getExpiringPlans(
            @RequestParam(value = "days", defaultValue = "7") int days) {
        logger.info("Fetching recharge records expiring within {} days", days);
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime threshold = now.plusDays(days);
        List<RechargeHistory> expiringPlans = rechargeHistoryRepository.findAll().stream()
            .filter(r -> r.getExpiryDate().isAfter(now) && r.getExpiryDate().isBefore(threshold))
            .collect(Collectors.toList());
        logger.info("Expiring plans fetched: {}", expiringPlans);
        return ResponseEntity.ok(expiringPlans);
    }

    @GetMapping("/revenue")
    public ResponseEntity<Map<String, Object>> getRevenueData() {
        LocalDateTime now = LocalDateTime.now();
        List<RechargeHistory> allRecharges = rechargeHistoryRepository.findAll();

        // Last 6 months revenue
        Map<String, Double> monthlyRevenue = new TreeMap<>();
        for (int i = 5; i >= 0; i--) {
            LocalDateTime start = now.minusMonths(i).withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
            LocalDateTime end = start.plusMonths(1).minusSeconds(1);
            String month = start.format(DateTimeFormatter.ofPattern("MMM"));
            
            double revenue = allRecharges.stream()
                .filter(r -> !r.getRechargeDate().isBefore(start) && !r.getRechargeDate().isAfter(end))
                .mapToDouble(RechargeHistory::getAmount)
                .sum();
            monthlyRevenue.put(month, revenue);
        }

        double currentMonthRevenue = monthlyRevenue.get(now.format(DateTimeFormatter.ofPattern("MMM")));

        Map<String, Object> response = new HashMap<>();
        response.put("currentMonth", currentMonthRevenue);
        response.put("lastSixMonths", new HashMap<String, Object>() {{
            put("labels", monthlyRevenue.keySet().toArray());
            put("values", monthlyRevenue.values().toArray());
        }});

        return ResponseEntity.ok(response);
    }

    @GetMapping("/popular-plans")
    public ResponseEntity<List<Map<String, Object>>> getPopularPlans() {
        List<RechargeHistory> allRecharges = rechargeHistoryRepository.findAll();
        
        List<Map<String, Object>> popularPlans = allRecharges.stream()
            .collect(Collectors.groupingBy(RechargeHistory::getPlanName, Collectors.counting()))
            .entrySet().stream()
            .map(entry -> {
                Map<String, Object> map = new HashMap<>();
                map.put("planName", entry.getKey());
                map.put("count", entry.getValue());
                return map;
            })
            .sorted((a, b) -> Long.compare((Long)b.get("count"), (Long)a.get("count")))
            .limit(5)
            .collect(Collectors.toList());

        return ResponseEntity.ok(popularPlans);
    }
}