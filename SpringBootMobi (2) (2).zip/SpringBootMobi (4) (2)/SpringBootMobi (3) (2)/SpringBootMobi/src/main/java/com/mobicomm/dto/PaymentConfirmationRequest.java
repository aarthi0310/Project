package com.mobicomm.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentConfirmationRequest {
    private String phoneNumber;
    private String planName;
    private Double amount;
    private String paymentMethod;
    private String transactionId;
    private String validity;
}