package com.mobicomm.service;

import com.mobicomm.entity.RechargeHistory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Async
    public void sendRechargeConfirmationEmail(String toEmail, RechargeHistory recharge) {
        try {
            logger.info("Sending recharge confirmation email to: {}", toEmail);
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            message.setSubject("Mobi-Comm Recharge Confirmation");
            message.setText(buildEmailBody(recharge));
            message.setFrom(fromEmail);
            mailSender.send(message);
            logger.info("Recharge confirmation email sent successfully to: {}", toEmail);
        } catch (Exception e) {
            logger.error("Failed to send recharge confirmation email to {}: {}", toEmail, e.getMessage(), e);
            throw e; // Re-throw to propagate the error
        }
    }

    @Async
    public void sendExpiryNotificationEmail(String toEmail, RechargeHistory recharge, int daysLeft) {
        try {
            logger.info("Sending expiry notification email to: {}", toEmail);
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            message.setSubject("Mobi-Comm Plan Expiry Alert");
            message.setText(buildExpiryEmailBody(recharge, daysLeft));
            message.setFrom(fromEmail);
            mailSender.send(message);
            logger.info("Expiry notification email sent successfully to: {}", toEmail);
        } catch (Exception e) {
            logger.error("Failed to send expiry notification email to {}: {}", toEmail, e.getMessage(), e);
            throw e; // Re-throw to propagate the error
        }
    }

    private String buildEmailBody(RechargeHistory recharge) {
        return "Dear Customer,\n\n" +
               "Your recharge has been successfully completed!\n\n" +
               "Recharge Details:\n" +
               "Plan Name: " + recharge.getPlanName() + "\n" +
               "Amount: ₹" + recharge.getAmount() + "\n" +
               "Payment Method: " + recharge.getPaymentMethod() + "\n" +
               "Transaction ID: " + recharge.getTransactionId() + "\n" +
               "Recharge Date: " + recharge.getRechargeDate() + "\n" +
               "Expiry Date: " + recharge.getExpiryDate() + "\n\n" +
               "Thank you for choosing Mobi-Comm!\n" +
               "For support, contact: support@mobi-comm.com\n\n" +
               "Best Regards,\n" +
               "Mobi-Comm Team";
    }

    private String buildExpiryEmailBody(RechargeHistory recharge, int daysLeft) {
        return "Dear " + recharge.getName() + ",\n\n" +
               "This is a reminder that your Mobi-Comm plan is expiring soon!\n\n" +
               "Plan Details:\n" +
               "Plan Name: " + recharge.getPlanName() + "\n" +
               "Phone Number: " + recharge.getPhoneNumber() + "\n" +
               "Expiry Date: " + recharge.getExpiryDate() + "\n" +
               "Days Left: " + daysLeft + " day(s)\n\n" +
               "Please recharge your plan to continue enjoying uninterrupted services.\n" +
               "Visit our website or contact support for assistance.\n\n" +
               "Best Regards,\n" +
               "Mobi-Comm Team\n" +
               "support@mobi-comm.com";
    }
}