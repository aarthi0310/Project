package com.mobicomm.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "plans")
@NoArgsConstructor
@AllArgsConstructor
public class Plan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Double price;
    private String data;
    private String validity;
    private String category;
    private Boolean active;
   
   
    public boolean isActive() {
        return active != null ? active : false; 
    }

    
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    public String getValidity() { return validity; }
    public void setValidity(String validity) { this.validity = validity; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public void setActive(Boolean active) { this.active = active; }
}